function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ZH52MAcUK4":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

